# Symbols forward-index style search

Variant **06_prefix_root** is provisionally selected. Its `Trie.get` meets all three unchanged targets. This is one passing declaration out of 22 reviewed units, not a complete-family or completed-campaign pass. Final semantic, mutation, additive adversarial/invariant, performance and integration gates belong to the coordinator and are not claimed by this scratch report.

All seven candidate sources are retained. No production source, original model, law, assertion, expected observation or rubric was edited by this lane. Every copied non-main package Bend file matches the frozen input snapshot byte-for-byte. All source changes after the first three exploratory designs were written into new directories; earlier candidate sources remain unchanged.

The fixed style target is at least 60% normalized probability on levels 3 and 4, independently for compression, reading pleasure and memetic identity. Scores below show those probability masses; the raw receipts preserve complete five-level distributions, context, hashes, requests and responses. Requested reviewer: `jev-latest`; observed reviewer identity is retained per receipt. Authoring was assigned to GPT-6 Astra at max reasoning.

## Search dispositions

| Variant | First candidate compile | Proof and native/JS conformance | Style coverage | All-axis passes | Disposition |
|---|---|---|---|---|---|
| 01_owned_stages | fail: nondecreasing recursion | not run | not scored | none | rejected_compiler |
| 02_owned_intent | pass | pass | 5/5 | none | rejected_style |
| 03_frontier | pass | pass | 13/13 | none | rejected_style_and_scope |
| 04_trie | pass | pass | 19/19 | `Trie.get`, `Trie.put` | rejected_cost |
| 05_balanced_trie | pass | pass | 23/23 | none | rejected_style_uncertain_other_axes |
| 06_prefix_root | pass | pass | 22/22 | `Trie.get` | provisionally_selected |
| 07_read_only | pass | pass | 20/20 | none | rejected_style_lost_memetic |

No unchanged candidate was rerun for a better score. Candidate 01 failed its first compiler check; candidates 02–07 each passed their first candidate check and required no candidate diagnostic retry. A separate constructor-lambda API probe in `04_trie/probes/` first lacked a type annotation; the annotated form then checked. That probe is not counted as a candidate first-shot result.

## Context and verification limits

Style review uses parsed declarations and bounded working-copy context. Datatype context is same-file only and does not resolve imported or transitive dependencies. Function context retains helper/caller/file/byte limits and unresolved references. Each row in `search.json` includes the exact context object and complete answer distributions. `style.json` remains the raw authority for each run. Compiler/proof/runtime gates are separate from style coverage.

The selected `06_prefix_root::Trie.get` row is not truncated. Its context cap is 16 helpers, 4 callers, 12 files and 48,000 bytes; unresolved-or-builtin flags remain for `Trie`, `String`, `U32`, `Cmp` and `U32.cmp`. The two truncated rows in variants 04–07 are the `Trie` and `Table` datatype reviews. Variant 03 truncates `Table`. Those limits remain part of the evidence, not a reason to infer unseen quality.

| Variant | Truncated targets | Targets with unresolved context | Unresolved references | Observed model |
|---|---:|---:|---:|---|
| 02_owned_intent | 0 | 5 | 24 | jev-1.13.0 |
| 03_frontier | 1 | 13 | 65 | jev-1.13.0 |
| 04_trie | 2 | 19 | 101 | jev-1.13.0 |
| 05_balanced_trie | 2 | 23 | 121 | jev-1.13.0 |
| 06_prefix_root | 2 | 22 | 114 | jev-1.13.0 |
| 07_read_only | 2 | 20 | 108 | jev-1.13.0 |

The original `PROOF.bend` gate retains its existing proof boundary; it does not by itself prove a newly introduced balancing algorithm correct. The selected representation needs separate invariant and adversarial validation. This report records only gates run by this lane. Coordinator results are deliberately not inferred from their progress messages.

## 01_owned_stages

A computed next phase is not a structurally decreasing recursive argument. No proof, runtime or style pass was claimed.

Source: [`main.bend`](01_owned_stages/main.bend)
SHA-256: `3e5e6c0b9454153f24446fe8f486468b1d91951e8fcb8735e0b91d1a1f0673e1`

**Reading hypothesis.** Represent each outstanding ownership boundary as Lookup, Slot, or Commit. One recursive dispatcher should make the lookup-hit return and successful-commit return visibly identical, while the phase constructors carry the exact owned API results required for the next decision.

Compiler diagnostic:

```text
Error:
- expected : a decreasing self-call (arguments are read left to right: each passed unchanged until one shrinks)
- observed : intern
Context:
- name  : String
- names : 0xd684886d10b431b9dce6c3b2d1ef1980/main.Vec<String>
- ids   : Map<&2, Maybe<&2, U32>>
Location: intern
50 |         case Some{id}: (InternTable{names,ids},Done{id})
51>|         case None{}: intern(name,Slot{ids,V.Vec.length(String,names)})
   |                      ^^^^^^
52 |     case Slot{ids,position}:
```

## 02_owned_intent

Finite owned prepare/commit intent preserves behavior, but no reviewed declaration meets all three style targets.

Source: [`main.bend`](02_owned_intent/main.bend)
SHA-256: `690f3caecff7290c81a2b5464d5e2dc40b3cc58c20836133ababe0d0a94c4b3e`

**Reading hypothesis.** An owned Intern value separates reuse from publication. Discovery produces either an existing table/ID or a single pending publication containing the reverse append result; commit is the only place allowed to finish that publication. This gives both success paths one terminal interpretation without a recursive transition loop.

Evidence: [gates](02_owned_intent/gates.json), [complete style receipt](02_owned_intent/style.json), [style output](02_owned_intent/style.stdout).

| Declaration | Compression | Delight | Memetic | All three |
|---|---:|---:|---:|---|
| `Intern` | 61.00% | 54.00% | 18.00% | no |
| `commit` | 67.00% | 51.00% | 10.00% | no |
| `reserve` | 86.00% | 46.00% | 6.00% | no |
| `locate` | 73.00% | 41.00% | 14.00% | no |
| `Table.intern` | 76.00% | 58.00% | 30.00% | no |

## 03_frontier

Caching the next ID removes a metadata continuation but adds a maintained representation invariant; no all-axis style pass justifies that broader change.

Source: [`main.bend`](03_frontier/main.bend)
SHA-256: `34219d637345f21b32d2c6febf60a08e9aa1c42737df09dd59fb864a68dede12`

**Reading hypothesis.** Make the allocation frontier an owned Table coordinate. The same number is the public length and the next new ID; successful commit increments it exactly once and failure retains it. This removes the metadata continuation from insertion and puts the correspondence between allocation and cardinality in each constructor reconstruction.

Evidence: [gates](03_frontier/gates.json), [complete style receipt](03_frontier/style.json), [style output](03_frontier/style.stdout).

| Declaration | Compression | Delight | Memetic | All three |
|---|---:|---:|---:|---|
| `Table` | 74.00% | 49.00% | 6.00% | no |
| `Table.bounded` | 87.00% | 54.00% | 3.00% | no |
| `Table.new` | 93.00% | 54.00% | 4.00% | no |
| `Table.length` | 96.97% | 57.00% | 3.00% | no |
| `limited` | 95.00% | 57.00% | 2.00% | no |
| `Table.limit` | 89.00% | 56.00% | 5.00% | no |
| `found` | 85.00% | 47.00% | 4.00% | no |
| `Table.find` | 84.00% | 48.00% | 10.00% | no |
| `commit` | 71.00% | 64.00% | 7.00% | no |
| `claim` | 86.00% | 67.00% | 20.20% | no |
| `Table.intern` | 79.00% | 72.00% | 23.00% | no |
| `resolved` | 74.00% | 58.00% | 2.00% | no |
| `Table.resolve` | 83.00% | 60.00% | 5.00% | no |

## 04_trie

Trie.get and Trie.put meet all three targets, but unbalanced sibling trees admit linear lookup depth on sorted distinct single-character names. That asymptotic regression prevents adoption.

Source: [`main.bend`](04_trie/main.bend)
SHA-256: `8833421f56c5d7686800ed1e712abad777ade6b7fe37c3ede20065c3e1135354`

**Reading hypothesis.** Expose exact strings as a ternary character language. One traversal grammar keeps the current suffix on less/more edges and consumes precisely one character on the same edge. Lookup and insertion should mirror this geometry, so the reader can recognize both the search invariant and the update path.

Evidence: [gates](04_trie/gates.json), [complete style receipt](04_trie/style.json), [style output](04_trie/style.stdout).

| Declaration | Compression | Delight | Memetic | All three |
|---|---:|---:|---:|---|
| `Trie` | 66.00% | 74.00% | 51.00% | no |
| `Trie.path` | 87.00% | 69.00% | 7.00% | no |
| `Trie.rejoin` | 97.00% | 69.00% | 24.00% | no |
| `Trie.get` | 76.00% | 83.00% | 68.00% | pass |
| `Trie.put` | 80.00% | 92.00% | 70.00% | pass |
| `Table` | 67.00% | 41.00% | 5.00% | no |
| `Table.bounded` | 97.00% | 61.00% | 2.00% | no |
| `Table.new` | 92.00% | 40.00% | 2.00% | no |
| `metadata` | 84.00% | 44.00% | 4.00% | no |
| `Table.length` | 77.00% | 24.00% | 2.00% | no |
| `Table.limit` | 86.00% | 29.00% | 4.00% | no |
| `found` | 88.00% | 44.00% | 2.00% | no |
| `Table.find` | 84.00% | 52.00% | 40.00% | no |
| `inserted` | 89.00% | 71.00% | 6.00% | no |
| `append_name` | 91.00% | 51.00% | 7.00% | no |
| `intern_found` | 76.00% | 60.00% | 19.00% | no |
| `Table.intern` | 66.00% | 73.74% | 45.00% | no |
| `resolved` | 44.00% | 41.00% | 1.00% | no |
| `Table.resolve` | 77.00% | 41.00% | 4.00% | no |

## 05_balanced_trie

Balanced sibling trees preserve the behavior gates. Trie.get has memetic mass 0.66 and delight 0.68, but compression 0.58 is uncertain; no declaration meets every target. The extra Letter wrapper also complicates the traversal.

Source: [`main.bend`](05_balanced_trie/main.bend)
SHA-256: `babfe9205dd805928984307cd59fdb7fe764fe111854a33b94d977ecb387a491`

**Reading hypothesis.** Store the current character and its same/tail subtree together as one owned Letter, then balance only the less/more sibling tree. The four red-red rotations should share one reconstruction grammar while the lookup and insertion keep their earned less/same/more rhythm.

Evidence: [gates](05_balanced_trie/gates.json), [complete style receipt](05_balanced_trie/style.json), [style output](05_balanced_trie/style.stdout).

| Declaration | Compression | Delight | Memetic | All three |
|---|---:|---:|---:|---|
| `Color` | 80.00% | 53.00% | 8.00% | no |
| `Trie` | 68.00% | 79.00% | 58.00% | no |
| `Letter` | 57.00% | 32.00% | 10.00% | no |
| `Trie.black` | 91.00% | 53.00% | 2.00% | no |
| `Trie.balance` | 32.00% | 84.00% | 21.00% | no |
| `Trie.rejoin` | 97.00% | 64.00% | 18.00% | no |
| `Trie.get` | 58.00% | 68.00% | 66.00% | no |
| `Trie.insert` | 51.00% | 85.00% | 53.00% | no |
| `Trie.put` | 92.00% | 66.00% | 18.00% | no |
| `Table` | 72.00% | 47.00% | 7.00% | no |
| `Table.bounded` | 97.00% | 63.00% | 2.00% | no |
| `Table.new` | 95.00% | 43.00% | 2.00% | no |
| `metadata` | 81.00% | 38.00% | 4.00% | no |
| `Table.length` | 87.00% | 31.00% | 2.00% | no |
| `Table.limit` | 88.00% | 37.00% | 3.00% | no |
| `found` | 87.00% | 49.00% | 2.00% | no |
| `Table.find` | 84.00% | 44.00% | 33.00% | no |
| `inserted` | 86.00% | 64.00% | 6.00% | no |
| `append_name` | 88.00% | 53.00% | 10.00% | no |
| `intern_found` | 82.00% | 66.00% | 17.00% | no |
| `Table.intern` | 64.00% | 67.00% | 38.00% | no |
| `resolved` | 55.00% | 46.00% | 1.00% | no |
| `Table.resolve` | 78.00% | 36.00% | 5.00% | no |

## 06_prefix_root

Trie.get meets every target with a balanced prefix-root representation. Selection remains provisional pending coordinator semantic review, mutations, additive adversarial/invariant checks, performance acceptance and integration. The complete changed family is not a style pass.

Source: [`main.bend`](06_prefix_root/main.bend)
SHA-256: `8e44e7b0b147ad90cee9c049d62d44d8ba14bcbf0b7b07bc45044c24d2eacbeb`

**Reading hypothesis.** A prefix may own a terminal ID before its red-black character siblings. Keep Here outside the balanced sibling tree, so empty-string behavior is direct and less/same/more retains the successful unbalanced traversal shape. Balancing moves character plus same/tail subtree together without introducing a Letter datatype.

Evidence: [gates](06_prefix_root/gates.json), [complete style receipt](06_prefix_root/style.json), [style output](06_prefix_root/style.stdout).

| Declaration | Compression | Delight | Memetic | All three |
|---|---:|---:|---:|---|
| `Color` | 79.00% | 55.00% | 9.00% | no |
| `Trie` | 65.00% | 78.00% | 57.00% | no |
| `Trie.black` | 85.00% | 64.00% | 4.00% | no |
| `Trie.balance` | 18.00% | 64.00% | 27.00% | no |
| `Trie.rejoin` | 97.00% | 63.00% | 17.00% | no |
| `Trie.get` | 69.00% | 74.00% | 62.00% | pass |
| `Trie.insert` | 59.00% | 78.00% | 54.00% | no |
| `Trie.put` | 87.00% | 61.00% | 21.00% | no |
| `Table` | 74.00% | 49.00% | 5.00% | no |
| `Table.bounded` | 97.00% | 58.00% | 2.00% | no |
| `Table.new` | 93.00% | 37.00% | 2.00% | no |
| `metadata` | 83.00% | 40.00% | 4.00% | no |
| `Table.length` | 83.00% | 27.00% | 3.00% | no |
| `Table.limit` | 84.00% | 30.00% | 3.00% | no |
| `found` | 88.00% | 46.00% | 2.00% | no |
| `Table.find` | 83.00% | 44.00% | 33.00% | no |
| `inserted` | 85.00% | 66.00% | 7.00% | no |
| `append_name` | 88.00% | 49.00% | 10.00% | no |
| `intern_found` | 80.00% | 63.00% | 18.00% | no |
| `Table.intern` | 60.00% | 66.00% | 40.00% | no |
| `resolved` | 53.00% | 41.00% | 1.00% | no |
| `Table.resolve` | 76.00% | 35.00% | 5.00% | no |

## 07_read_only

Declaring the scalar trie Data and removing lookup path reconstruction preserves behavior and is a useful alternative. Its read-only Trie.get loses the memetic pass (0.46); no declaration meets all targets.

Source: [`main.bend`](07_read_only/main.bend)
SHA-256: `dfd1fd86e961bfafa46bb6bac4e3069cde491bc0dbc1eeb8786eddc4421f356d`

**Reading hypothesis.** The forward trie contains only immutable scalar data and recursive scalar tries. Declare that fact as Data and let lookup return only its answer, removing ownership reconstruction from the search grammar. The Table remains affine because its reverse Vec remains owned.

Evidence: [gates](07_read_only/gates.json), [complete style receipt](07_read_only/style.json), [style output](07_read_only/style.stdout).

| Declaration | Compression | Delight | Memetic | All three |
|---|---:|---:|---:|---|
| `Color` | 79.00% | 51.00% | 8.00% | no |
| `Trie` | 66.00% | 83.00% | 56.00% | no |
| `Trie.black` | 85.00% | 62.00% | 5.00% | no |
| `Trie.balance` | 19.00% | 66.00% | 27.00% | no |
| `Trie.get` | 61.00% | 66.00% | 46.00% | no |
| `Trie.insert` | 57.00% | 76.00% | 57.00% | no |
| `Trie.put` | 89.00% | 61.00% | 17.00% | no |
| `Table` | 68.00% | 43.00% | 4.04% | no |
| `Table.bounded` | 97.00% | 60.00% | 2.00% | no |
| `Table.new` | 94.00% | 45.00% | 2.00% | no |
| `metadata` | 77.00% | 33.00% | 3.00% | no |
| `Table.length` | 82.00% | 28.00% | 2.00% | no |
| `Table.limit` | 88.00% | 31.00% | 3.03% | no |
| `Table.find` | 93.00% | 48.00% | 23.00% | no |
| `inserted` | 86.00% | 66.00% | 7.00% | no |
| `append_name` | 87.00% | 48.00% | 10.00% | no |
| `intern_found` | 80.00% | 60.00% | 14.00% | no |
| `Table.intern` | 61.00% | 67.00% | 30.00% | no |
| `resolved` | 40.00% | 32.00% | 1.00% | no |
| `Table.resolve` | 70.00% | 30.00% | 5.00% | no |

## Complexity disposition

Variant 04 follows one search path but is unbalanced. For `n` strictly increasing distinct one-character names, its more-spine has `n` character forks: finding the largest name visits those `n` forks and its `Here`; finding a larger absent character visits those `n` forks and `Vacant`. This is a source-derived count, not an instrumented measurement. The linear-depth case is the reason for rejecting 04 despite its style passes.

Variant 06 keeps a terminal `Here` only at each prefix root. Its `more` is a sibling tree containing only `Fork`/`Vacant`; `less` and `more` sibling edges never contain `Here`. Each `same` child is an independent prefix trie, blackened after insertion. Red-black balancing addresses the sibling-depth regression, subject to independent validation of those invariants and measured cost.

Variant 07 keeps the exact balancing/blackening/insertion/put definitions of 06, declares the scalar trie `Data`, and performs read-only lookup. The owning `Table` remains `Type` because it owns the pinned `Vec`. This removes path reconstruction but does not meet the memetic target in the retained review. Runtime implications belong to the coordinator measurements.

